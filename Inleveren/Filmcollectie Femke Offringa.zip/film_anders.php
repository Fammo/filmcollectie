<?php
# 	linked naar de database
include_once("assets/php/config.php");
#	bevat alle gebruikte functies
include_once("assets/php/functions.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Femke Offringa | Filmcollectie</title>
	<link rel="stylesheet" href="assets/css/reset.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link href='http://fonts.googleapis.com/css?family=Nixie+One' rel='stylesheet' type='text/css'>
	<nav>										
			<ul>								
				<li><a href="index.php">Film overzicht</a></li>	
				<li><a href="film_beheer.php">Film toevoegen</a></li>	
				<li><a href="film_anders.php">Films aanpassen</a></li>	
			</ul>
		</nav>
</head>
<body>
	<h2> Verander hier filmdetails </h2>
		<p> Niet elke invoer is gelijk de eerste keer perfect. Daarom kunt u hieronder per film en per catagorie alsnog bepaalde gegevens aanpassen door deze in het kader te typen en op "Update" te klikken.</p>
		<br>
		<br>
 <?php
 	$link = connect_db();
 	$query = "SELECT * FROM movies ORDER BY title";
 	$result = mysqli_query($link,$query);
 	if(mysqli_num_rows($result)){
 		while($entry = mysqli_fetch_assoc($result)){
 ?>

 <div class="content_wijzigen">
<form id="changeMovie" action="process.php" method="post"<input type="hidden" name="action" value="changeMovie">

 <table>
 <tr>
 <td><p>Titel:</td>
 <td><input type="text" name="id" value="<?php echo $entry["title"];?>"></td> <br>
 <td><button type="change" value="Update">Update</button></td>
 </tr>
 <tr>
 <td>Actors:</td>
 <td><input type="text" name="id" value="<?php echo $entry["actors"];?>"></td>
  <td><button type="change" value="Update">Update</button></td>
 </tr>
  <tr>
 <td>Genre:</td>
 <td><input type="text" name="id" value="<?php echo $entry["genre"];?>"></td>
  <td><button type="change" value="Update">Update</button></td>
 </tr>
  <tr>
 <td>Year:</td>
 <td><input type="text" name="id" value="<?php echo $entry["year"];?>"></td>
  <td><button type="change" value="Update">Update</button></td>
 </tr>
 <tr>
  <td>Abstract:</td>
 <td><input type="text" name="id" value="<?php echo $entry["abstract"];?>"></td>
  <td><button type="change" value="Update">Update</button></td>
 </tr>
 <tr>
  <td>Rating:</td>
 <td><input type="text" name="id" value="<?php echo $entry["rating"];?>"></td>
  <td><button type="change" value="change">Update</button></td>
 </tr>
 </p></table>
</form>
</div>

<?php } //end while
		} // end if?>
<footer>
		<ul>
 			 <li>femke offringa</li> 
 			 <li><a href="mailto:femke_offringa@hotmail.com">femke_offringa@hotmail.com</a></li>
 			 <li>0623215100</li>
 		 </ul>
	</footer>
</body>
</html>