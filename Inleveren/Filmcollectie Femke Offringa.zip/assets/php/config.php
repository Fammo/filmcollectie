<?php
define('DBSERVER',"localhost");
define('DBUSER',"root");
define('DBPASS',"");
define('DBNAME',"Filmcollectie");
?>