<?php
# 	linked naar de database
include_once("assets/php/config.php");
#	bevat alle gebruikte functies
include_once("assets/php/functions.php");
?>
<!DOCTYPE html>
<html lang-"nl">
<head>
	<meta charget="UTF-8">
	<title>Femke Offringa | Filmcollectie</title>
	<link rel="stylesheet" href="assets/css/reset.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link href='http://fonts.googleapis.com/css?family=Nixie+One' rel='stylesheet' type='text/css'>
	<!--icon source: <div>Icons made by <a href="http://www.freepik.com" title="Freepik">Freepik</a> from <a href="http://www.flaticon.com" title="Flaticon">www.flaticon.com</a>             is licensed by <a href="http://creativecommons.org/licenses/by/3.0/" title="Creative Commons BY 3.0">CC BY 3.0</a></div>-->
	<nav>										
			<ul>								
				<li><a href="index.php">Film overzicht</a></li>	
				<li><a href="film_beheer.php">Film toevoegen</a></li>
				<li><a href="film_anders.php">Films aanpassen</a></li>	
			</ul>
		</nav>
</head>
<body>
	<div class="search">
	    <form  method="get" action="overview.php" id="searchMovie"> 
		<input  type="search" name="s" placeholder="Typ hier je zoekterm"> 
		<input  type="submit" name="submit" value="Zoek"> 
		</form> 
	</div>

	 <?php
	 	$link = connect_db(); //verbind met database
	 	$query = "SELECT * FROM movies ORDER BY title"; //toon alles uit movies en order op titel
	 	$result = mysqli_query($link,$query); //stuur resultaat naar database
	 	if(mysqli_num_rows($result)){	//zolang er regels zijn haal deze op
	 		while($entry = mysqli_fetch_assoc($result)){ //toon resultaten
	 ?>

 	<article class="entry" id="entry-<?php echo $entry['id']?>">
		<table>
		<h2><?php echo $entry["title"] ?></h2>
			<tr>
				<td><p>Beoordeling:</p></td>
				<td><?php if($entry["rating"] == 1){ //als de invoer 1 is toon 1 ster?>
					<img src= "assets/gfx/star.gif" height="15" width="15">
					<?php } //end if?>
				<?php if($entry["rating"] == 2){ //als de invoer 2 is toon 2 sterren?>
					<img src= "assets/gfx/star.gif" height="15" width="15">
					<img src= "assets/gfx/star.gif" height="15" width="15">
					<?php } //end if?>
				<?php if($entry["rating"] == 3){ //als de invoer 3 is toon 3 sterren?>
					<img src= "assets/gfx/star.gif" height="15" width="15">
					<img src= "assets/gfx/star.gif" height="15" width="15">
					<img src= "assets/gfx/star.gif" height="15" width="15">
					<?php } //end if?>
				<?php if($entry["rating"] == 4){ //als de invoer 4 is toon 4 sterren?>
					<img src= "assets/gfx/star.gif" height="15" width="15">
					<img src= "assets/gfx/star.gif" height="15" width="15">
					<img src= "assets/gfx/star.gif" height="15" width="15">
					<img src= "assets/gfx/star.gif" height="15" width="15">
					<?php } //end if?>
				<?php if($entry["rating"] == 5){ //als de invoer 5 is toon 5 sterren?>
					<img src= "assets/gfx/star.gif" height="15" width="15">
					<img src= "assets/gfx/star.gif" height="15" width="15">
					<img src= "assets/gfx/star.gif" height="15" width="15">
					<img src= "assets/gfx/star.gif" height="15" width="15">
					<img src= "assets/gfx/star.gif" height="15" width="15">
					<?php } //end if?>
				</td>
			</tr>
			<tr>
				<p><td>Genre:</td>
				<td><?php echo $entry["genre"];?></td>
			</tr>
			<tr>
				<td>Jaar van uitkomst:</td>
				<td><?php echo $entry["year"]."<br />";?></td>
			</tr>
			<tr>
				<td>Samenvatting:</td>
				<td><?php echo $entry["abstract"]."<br />";?></td>
			</tr></p>
		</table>

		<div class="film col_12 white_bg">
			<form action="process.php" method="post" class="delete">
				<input type="hidden" name="action" value="deleteMovie">
				<input type="hidden" name="id" value="<?php echo $entry['id']?>">
				<button type="delete" value="delete">Delete</button> 
			</form>
			<?php	} //endif	?>
		</div>
	</article>
			<?php 	} //endwhile ?>
<footer>
		<ul>
 			 <li>femke offringa</li> 
 			 <li><a href="mailto:femke_offringa@hotmail.com">femke_offringa@hotmail.com</a></li>
 			 <li>0623215100</li>
 		 </ul>
	</footer>
</body>
</html>